const express = require("express");
const app = express();

app.get("/", (req, res) => {
    res.send("Mi blog backend está funcionando");
});

app.listen(3000, () => {
    console.log("Servidor funcionando en http://localhost:3000");
});

app.get("/api/blog", (req, res) => {

    res.json({
        nombre: "Mi Blog",
        curso: "Desarrollo Web",
        estado: "Funcionando"
    });

});

app.get("/api/articulos", (req, res) => {

    res.json([
        {
            id: 1,
            titulo: "Mi primer artículo",
            autor: "Carlos"
        },
        {
            id: 2,
            titulo: "Aprendiendo Backend",
            autor: "Ana"
        },
        {
            id: 3,
            titulo: "Node.js y Express",
            autor: "Pedro"
        }
    ]);

});

app.get("/api/articulos/:id", (req, res) => {

    res.json({
        mensaje: "Artículo solicitado",
        id: req.params.id
    });

});

app.get("/api/calculadora/:operacion/:a/:b", (req, res) => {

    const operacion = req.params.operacion;
    const a = Number(req.params.a);
    const b = Number(req.params.b);

    let resultado;

    if (operacion === "suma") {
        resultado = a + b;
    }
    else if (operacion === "resta") {
        resultado = a - b;
    }
    else if (operacion === "multiplicacion") {
        resultado = a * b;
    }
    else if (operacion === "division") {
        resultado = a / b;
    }
    else {
        return res.json({
            error: "Operación no válida"
        });
    }

    res.json({
        operacion: operacion,
        numero1: a,
        numero2: b,
        resultado: resultado
    });

});